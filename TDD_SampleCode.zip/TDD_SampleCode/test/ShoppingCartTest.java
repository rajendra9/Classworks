package test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import code.Book;
import code.Cd;
import code.Product;
import code.ShoppingCart;
import code.ShoppingCartDAO;
import code.ShoppingCartService;

public class ShoppingCartTest {

	ShoppingCart cart;
	
	//@BeforeClass
	
	//@AfterClass
	
	
	@Before
	public void setup(){
		cart = new ShoppingCart();
	}
	
	@After
	public void tearDown(){
		cart = null;
	}
	
	@Test
	public void testAddItemsToBasket(){
		
		cart.addItems(new Product("PEN", 50.0, 2));
		cart.addItems(new Product("PENCIL",5.0, 5));
		Assert.assertEquals(2, cart.getItemCount());
	}
	
	@Test
	public void testBasketTotalValue(){
		cart.addItems(new Product("PEN", 50.0, 2));
		cart.addItems(new Product("PENCIL",5.0, 5));
		Assert.assertEquals(125.0, cart.getTotalValue(), 0.001);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testAddItemsWithNegativePrice(){
		cart.addItems(new Product("PEN", -50.0, 2));
	}
	
	@Test
	public void testAddItemsWithZeroPrice(){
		cart.addItems(new Product("PEN", 0.0, 2));
		Assert.assertEquals(1, cart.getItemCount());
	}	
	
	@Test
	public void testAddSaleTaxToTheCart(){
		cart.addItems(new Product("PEN", 50.0, 2));
		cart.addItems(new Product("PENCIL",5.0, 5));
		Assert.assertEquals(137.50, cart.getTotalValueWithTax(), 0.001);
	}
	
	@Test
	public void testAddSaleTaxToTheCartFromInput(){
		cart.addItems(new Product("PEN", 50.0, 2));
		cart.addItems(new Product("PENCIL",5.0, 5));
		Assert.assertEquals(143.75, cart.getTotalValueWithTax(0.15), 0.001);
	}
	
	@Test
	public void testAddDifferentProductTypeToCart(){
		cart.addItems(new Book("TDD", 300.0, 1));
		cart.addItems(new Cd("Angular Tutorials", 250.0, 1));
		Assert.assertEquals(2, cart.getItemCount());
	}
	
	@Test
	public void testSaveCartIntheDatabase(){
		cart.addItems(new Book("TDD", 300.0, 1));
		cart.addItems(new Cd("Angular Tutorials", 250.0, 1));
		ShoppingCartService service = new ShoppingCartService();
		
		ShoppingCartDAO mockShoppingCartDAO = Mockito.mock(ShoppingCartDAO.class);
		service.setCartDAO(mockShoppingCartDAO);
		Mockito.when(mockShoppingCartDAO.save(cart)).thenReturn(true);
		
		Assert.assertTrue(service.saveCart(cart));
	}
	
}


