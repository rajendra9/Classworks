
var uiRouteApp = angular.module("uiRouteApp", ['ui.router']);
uiRouteApp.config(['$stateProvider','$urlRouterProvider', function($stateProvider,$urlRouterProvider){
		
		$urlRouterProvider.otherwise("/home");  // default state.
		
		$stateProvider.state('home',{
			url:'/home',
			templateUrl:'templates/home.html'
		})
		$stateProvider.state("participantParent",{
			url:'/participants',
			templateUrl:'templates/participantParent.html',
			controller:'ParticipantParentController'
		})
		$stateProvider.state('participantParent.participants',{
			url:'/',
			templateUrl:'templates/participants.html',
			controller:'ListParticipantController'
		})
		$stateProvider.state('participantParent.participantDetails',{
			url:'/:participantId',
			templateUrl:'templates/participantDetails.html',
			controller:'ParticipantDetailsController'
		})
		$stateProvider.state('register',{
			url:'/register',
			templateUrl:'templates/register.html',
			controller: 'RegisterController'	
		})
		
}]);


uiRouteApp.controller("RegisterController", function($scope, $log, $http){
	
	$scope.message = "";
	$scope.registerParticipant = function(){
		
		$http({
			method: 'POST',
			url:'http://localhost:8080/HttpServiceUsage/Participant/',
			data : $scope.participant
		}).then(function success(response){
				$log.info("Participant registration completed successfully.")
				$scope.message ="Participant registration completed successfully";
		}, function error(response){
			$scope.message ="Participant registration failed.";
		});
	}
})
 

uiRouteApp.controller("ListParticipantController", function($scope, $log, $http){
	$scope.participantList = [];
	$http({
		method: 'GET',
		url:'http://localhost:8080/HttpServiceUsage/Participant/',
	}).then(
			function success(response){
				$log.info(response.data);
				$scope.participantList = response.data;
			},
			function error(response){
				$log.error("Error during Load.");
			}
	    ); 
});

uiRouteApp.controller("ParticipantDetailsController", function($scope, $log, $http, $stateParams){
	$scope.participant = {};
	$http({
		method: 'GET',
		url:'http://localhost:8080/HttpServiceUsage/Participant/'+ $stateParams.participantId,
	}).then(
			function success(response){
				$log.info(response.data);
				$scope.participant = response.data;
			},
			function error(response){
				$log.error("Error during Load.");
			}
	    ); 
});


uiRouteApp.controller("ParticipantParentController", function($scope, $log, $http, $stateParams){
	$scope.participantCount = {};
	$http({
		method: 'GET',
		url:'http://localhost:8080/HttpServiceUsage/getParticipantCount',
	}).then(
			function success(response){
				$log.info("Participants count loaded successfully.");
				$scope.participantCount = response.data;
			},
			function error(response){
				$log.error("Error during load.");
			}
	    ); 
});