package code;

public class Product {
	
	private String productName;
	private double unitPrice;
	private int quantity;
	
	public Product(String productName, int qty) {
		this.productName = productName;
		this.quantity = qty;
	}

	public Product(String productName, double unitPrice, int quantity) {
		super();
		this.productName = productName;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
