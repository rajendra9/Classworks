package code;

public class Cd extends Product {

	public Cd(String title, double price, int qty){
		super(title, price, qty);
	}
}
