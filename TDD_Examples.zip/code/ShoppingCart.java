package code;

import java.util.LinkedList;

public class ShoppingCart {
	
	public static final double DEFAULT_TAX = 0.10;
	
	LinkedList<Product> products = new LinkedList<Product>();
	
	public void addItems(Product product) throws IllegalArgumentException{
		if(product.getUnitPrice()<0)
			throw new IllegalArgumentException("Cannot add product with negative price");
		products.add(product);
		
	}

	public int getItemCount() {
		return products.size();
	}

	public double getTotalValue() {
		double totalValue = 0.0;
		for(Product product : products) {
			// find out the price of the product.
			totalValue = totalValue + (product.getQuantity() *  product.getUnitPrice()); 
		}
		return totalValue;
	}

	public double getTotalValueWithTax() {
		return getTotalValueWithTax(DEFAULT_TAX);
	}

	public double getTotalValueWithTax(double taxRate) {
		return getTotalValue() + (getTotalValue() * taxRate);
	}

}
