package code;

public class ShoppingCartService {

	ShoppingCartDAO cartDAO;
	
	
	public ShoppingCartDAO getCartDAO() {
		return cartDAO;
	}


	public void setCartDAO(ShoppingCartDAO cartDAO) {
		this.cartDAO = cartDAO;
	}


	public boolean saveCart(ShoppingCart cart) {
		return cartDAO.save(cart);
	}
}
