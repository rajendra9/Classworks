package com.htc.spring4.dao;

public interface AccountDAO {

	public boolean deposit(int accno, double amount);
	public boolean withdraw(int accno, double amount);
	public boolean transferAmount(int fromAccno, int toAccno, double amount);
	
}
