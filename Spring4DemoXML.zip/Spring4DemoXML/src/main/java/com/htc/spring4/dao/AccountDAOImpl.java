package com.htc.spring4.dao;

import org.springframework.jdbc.core.JdbcTemplate;

public class AccountDAOImpl implements AccountDAO{

	JdbcTemplate jdbcTemplate;
	
	public AccountDAOImpl(JdbcTemplate jdbcTemplate){
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public boolean deposit(int accno, double amount) {
		boolean depositStatus = false;
		int result = jdbcTemplate.update("UPDATE ACCOUNT SET BALANCE=BALANCE + ? WHERE ACCNO=?", amount, accno);
		if(result==1) 
			depositStatus = true;
		else
			throw new RuntimeException();
		
		return depositStatus;
	}

	public boolean withdraw(int accno, double amount) {
		boolean withdrawStatus = false;
		
		double availableBalance = jdbcTemplate.queryForObject("SELECT BALANCE FROM ACCOUNT WHERE ACCNO=?", new Object[]{accno}, java.lang.Double.class);		
		if(availableBalance >= amount) {
			int result = jdbcTemplate.update("UPDATE ACCOUNT SET BALANCE=BALANCE - ? WHERE ACCNO=?", amount, accno);
			if(result==1) 
				withdrawStatus = true;
			else
				throw new RuntimeException();
		}
		else
			throw new RuntimeException();
		return withdrawStatus;
	}

	public boolean transferAmount(int fromAccno, int toAccno, double amount) {
		boolean dstatus= deposit(toAccno, amount);
		boolean wstatus = withdraw(fromAccno, amount);
		return  dstatus&&wstatus ? true:false;
	}

	
}
