package com.htc.spring4.beans;

public class Student {
	
	private String rollno;
	private String studentName;
	private Address address;
	
	
	public Student(){
		
	}

	public Student(String rollno, String studentName) {
		super();
		this.rollno = rollno;
		this.studentName = studentName;
	}

	
	public Student(String rollno, String studentName, Address address) {
		super();
		this.rollno = rollno;
		this.studentName = studentName;
		this.address = address;
	}

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", studentName=" + studentName + ", address=" + address + "]";
	}
	
}
