package com.htc.spring4.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.htc.spring4.dao.AccountDAO;

public class TxTest {

	public static void main(String[] args) {
		
		ApplicationContext context=	new ClassPathXmlApplicationContext("aop.xml");
		AccountDAO accountDAO = (AccountDAO) context.getBean("accountDAO");
		
		System.out.println(accountDAO.transferAmount(1011, 1012, 3000.0));
		
	}
}
