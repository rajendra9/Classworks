package com.htc.spring4.aspect;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

public class LoggingAspect implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice{

	static Logger logger = Logger.getLogger("LoggingAspect");
	public void afterReturning(Object ret, Method method, Object[] param, Object target) throws Throwable {

		logger.info("Method name: " + method.getName());
		logger.info("Target object:" + target.getClass().getName());
		logger.info("Return value:" + ret);
	}

	public void before(Method method, Object[] params, Object target) throws Throwable {

		logger.info("Method name: " + method.getName());
		logger.info("Target object:" + target.getClass().getName());
		logger.info("Params value:" + params);
	}
	
	public void afterThrowing(Method method, Object[] args, Object target, Exception ex){
		logger.info("Method name: " + method.getName());
		logger.error("Error message:"  + ex.getMessage());
	}
}
