package com.htc.jsf.service;

import java.util.List;

import com.htc.jsf.bo.OrderDetails;
import com.htc.jsf.bo.Orders;
import com.htc.jsf.dao.OrderManagementDAO;
import com.htc.jsf.dao.OrderManagementDAOImpl;

public class OrderManagementService {

	public List<Orders> getOrders(){
		OrderManagementDAO orderDAO = new OrderManagementDAOImpl();
		return orderDAO.getOrders();
	}
	public List<OrderDetails> getOrderDetails(int orderId){
		OrderManagementDAO orderDAO = new OrderManagementDAOImpl();
		return orderDAO.getOrderDetails(orderId);
	}
	
}
