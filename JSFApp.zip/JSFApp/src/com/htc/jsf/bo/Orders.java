package com.htc.jsf.bo;

import java.util.Date;

public class Orders {
	private Integer orderId;
	private String customerName;
	private Date orderDate;
	
	public Orders(){}

	public Orders(Integer orderId, String customerName, Date orderDate) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.orderDate = orderDate;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", customerName=" + customerName + ", orderDate=" + orderDate + "]";
	}
	
	
}
