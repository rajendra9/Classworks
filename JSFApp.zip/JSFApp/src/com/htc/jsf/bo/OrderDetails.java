package com.htc.jsf.bo;

public class OrderDetails {

	private String productName;
	private int quantityOrdered;
	private double unitPrice;
	
	public OrderDetails(){}

	public OrderDetails(String productName, int quantityOrdered, double unitPrice) {
		super();
		this.productName = productName;
		this.quantityOrdered = quantityOrdered;
		this.unitPrice = unitPrice;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	@Override
	public String toString() {
		return "OrderDetails [productName=" + productName + ", quantityOrdered=" + quantityOrdered + ", unitPrice="
				+ unitPrice + "]";
	}
	
}
