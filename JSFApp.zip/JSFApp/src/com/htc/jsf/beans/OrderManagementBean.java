package com.htc.jsf.beans;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.htc.jsf.bo.OrderDetails;
import com.htc.jsf.bo.Orders;
import com.htc.jsf.service.OrderManagementService;

@ManagedBean(name="orderManagementBean")
@RequestScoped
public class OrderManagementBean {

	private int orderId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public List<Orders> getOrders(){
		OrderManagementService service = new OrderManagementService();
		return service.getOrders();
	}
	
	public List<OrderDetails> getOrderDetails(){
		OrderManagementService service = new OrderManagementService();
		return service.getOrderDetails(orderId);
	}
	
}
