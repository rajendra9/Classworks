package com.htc.jsf.dao;

import java.util.List;

import com.htc.jsf.bo.OrderDetails;
import com.htc.jsf.bo.Orders;

public interface OrderManagementDAO {

	public List<Orders> getOrders();
	public List<OrderDetails> getOrderDetails(int orderId);
	
}
