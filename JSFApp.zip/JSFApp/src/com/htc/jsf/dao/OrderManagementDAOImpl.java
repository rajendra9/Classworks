package com.htc.jsf.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.htc.jsf.bo.OrderDetails;
import com.htc.jsf.bo.Orders;

public class OrderManagementDAOImpl implements OrderManagementDAO{

	@Override
	public List<Orders> getOrders() {
		ArrayList<Orders> orders = new ArrayList<Orders>();
		orders.add(new Orders(12345,"Anand Enterprises", new Date()));
		orders.add(new Orders(12346,"HTC Holding Pvt Ltd", new Date()));
		orders.add(new Orders(12347,"Venkateswara Electronics", new Date()));
		
		return orders;
	}

	@Override
	public List<OrderDetails> getOrderDetails(int orderId) {
		ArrayList<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
		if(orderId == 12345){
			orderDetails.add(new OrderDetails("Reynolds Pen", 2, 20.00));
			orderDetails.add(new OrderDetails("Nataraj Pencil", 5, 10.00));
			orderDetails.add(new OrderDetails("Eraser", 2, 5.00));
		}
		else if(orderId == 12346){
			orderDetails.add(new OrderDetails("Reynolds Pen", 2, 20.00));
			orderDetails.add(new OrderDetails("Notebook 200 pages", 2, 40.00));
			orderDetails.add(new OrderDetails("Box", 1, 50.00));
		}
		else if(orderId == 12347){
			orderDetails.add(new OrderDetails("Reynolds Pen", 2, 20.00));
			orderDetails.add(new OrderDetails("Lunch Bag", 1, 150.00));
			orderDetails.add(new OrderDetails("Eraser", 2, 5.00));
		}
		return orderDetails;
	}

}
