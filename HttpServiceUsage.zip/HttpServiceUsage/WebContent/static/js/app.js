
var myApp = angular.module("eventApp",['ngMessages']);
  var eventController = myApp.controller("eventController", function($scope, $http, $log){
	
	  $scope.participants = [];
	  
	  // Registering a new pariticipant.
	  $scope.submitEventForm = function(){
		  
		  $log.info($scope.participant);
		  
		  $http({
			  method: 'POST',
			  url : 'http://localhost:8080/HttpServiceUsage/Participant/',
			  data: $scope.participant
		  }).then(
				  function successCallback(response){
					  $log.info("Event registration successful");
					  $log.info("Status:" + response.status);
					  $log.info("Status Text:" + response.statusText);
					  $log.info("Headers:" + response.headers);
					  $scope.showAllParticipants();
				  },
				  function errorCallback(response){
					  $log.info("Event registration failed.");
				  }
				  );
	  }

	  // Listing all participants.
	  $scope.showAllParticipants = function(){
		  
		  $http({
			  method: 'GET',
			  url : 'http://localhost:8080/HttpServiceUsage/Participant/',
		  }).then(
				  function successCallback(response){
					  $scope.participants = response.data;
				  },
				  function errorCallback(response){
					  $log.info("Event registration failed.");
				  }
				  );
	  }

	  $scope.showAllParticipants();
	  
  });