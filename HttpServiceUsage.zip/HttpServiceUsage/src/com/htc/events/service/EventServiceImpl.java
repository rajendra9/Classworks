package com.htc.events.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import com.htc.events.model.Participant;
@Service("eventService") 
public class EventServiceImpl implements EventService {

	private static final AtomicLong counter = new AtomicLong();
	
	private static List<Participant> participants;

	static{
		participants = new ArrayList<Participant>();
	}
	@Override
	public Participant findParticipantById(long participantId) {
		for(Participant p : participants) {
			if(p.getParticipantId() == participantId){
				return p;
			}
		}
		return null;
	}

	@Override
	public void registerParticipant(Participant participant) {
		participant.setParticipantId(counter.incrementAndGet());
		participants.add(participant);
	}

	@Override
	public void deleteParticipantById(long id) {
		Iterator<Participant> itr = participants.iterator();
		while(itr.hasNext()) {
			Participant p = itr.next();
			if(p.getParticipantId() == id) {
				itr.remove();
				break;
			}
		}
	}

	@Override
	public List<Participant> findAllParticipants() {
		return participants;
	}

}
