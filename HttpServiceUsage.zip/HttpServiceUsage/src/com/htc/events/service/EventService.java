package com.htc.events.service;

import java.util.List;

import com.htc.events.model.Participant;

public interface EventService {

	public Participant findParticipantById(long participantId);
	
	void registerParticipant(Participant participant);
	
	void deleteParticipantById(long id);

	List<Participant> findAllParticipants(); 
	

}
