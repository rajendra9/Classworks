package com.htc.spring4.dao;

import java.util.Date;
import java.util.List;

import com.htc.spring4.beans.Employee;

public interface EmployeeDAO {

	public boolean insertEmployee(Employee emp);
	
	public boolean insertEmployee(int empno, String empname, double salary, String job, int deptno, Date joindate);
	
	public Employee getEmployee(int empno);
	
	public List<Employee> getEmployees(int deptno);
	
	public List<Employee> getEmployees(String job);
	
	public String getEmployeeName(int empno);
	
	public boolean updateSalary(int empno, double newsalary);
	
	public boolean deleteEmployee(int empno);
	
	
}
