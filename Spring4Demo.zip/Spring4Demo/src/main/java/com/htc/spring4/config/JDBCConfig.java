package com.htc.spring4.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.htc.spring4.dao.EmployeeDAO;
import com.htc.spring4.dao.EmployeeDAOImpl;

@Configuration
public class JDBCConfig {

	@Bean(name="dataSource")
	public DataSource getDataSource(){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://localhost:5432/postgres");
		dataSource.setUsername("postgres");
		dataSource.setPassword("123Welcome");
		return dataSource;
	}
	
	@Bean(name="jdbcTemplate")
	public JdbcTemplate getJdbcTemplate(){
		JdbcTemplate jdbcTemplate = new JdbcTemplate(getDataSource());
		return jdbcTemplate;
	}
	
	@Bean(name="employeeDAO")
	public EmployeeDAO getEmployeeDAO(){
		EmployeeDAO employeeDAO = new EmployeeDAOImpl(getJdbcTemplate());
		return employeeDAO;
	}
	
	
}
