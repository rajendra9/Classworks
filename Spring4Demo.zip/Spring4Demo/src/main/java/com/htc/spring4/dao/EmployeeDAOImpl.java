package com.htc.spring4.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.htc.spring4.beans.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	
	JdbcTemplate jdbcTemplate;
	
	public EmployeeDAOImpl(JdbcTemplate jdbcTemplate){
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public boolean insertEmployee(Employee emp) {
		
		int result = jdbcTemplate.update("INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?)", emp.getEmpno(), emp.getEmpname(), emp.getSalary(), emp.getJob(), emp.getDeptno(), emp.getJoindate());
		if(result==1)
			return true;
		else return false;
	}

	public boolean insertEmployee(int empno, String empname, double salary, String job, int deptno, Date joindate) {
		int result = jdbcTemplate.update("INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?)", empno, empname, salary, job, deptno, joindate);
		if(result==1)
			return true;
		else return false;

	}

	public Employee getEmployee(int empno) {
		
		Employee emp = jdbcTemplate.queryForObject("SELECT EMPNO, EMPNAME, SALARY, JOB, DEPTNO, JOINDATE FROM EMPLOYEE WHERE EMPNO=?", 
								      new RowMapper<Employee>(){
										public Employee mapRow(ResultSet rs, int row) throws SQLException {

											Employee emp = new Employee();
											emp.setEmpno(rs.getInt(1));
											emp.setEmpname(rs.getString(2));
											emp.setSalary(rs.getDouble(3));
											emp.setJob(rs.getString(4));
											emp.setDeptno(rs.getInt(5));
											emp.setJoindate(rs.getDate(6));
											return emp;
									     }}, 
								      empno);
		return emp;
	}

	public List<Employee> getEmployees(int deptno) {
		
		List<Employee> empList = jdbcTemplate.query("SELECT EMPNO, EMPNAME, SALARY, JOB, DEPTNO, JOINDATE FROM EMPLOYEE where DEPTNO=?" , new RowMapper<Employee>(){

			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
				Employee emp = new Employee();
				emp.setEmpno(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setSalary(rs.getDouble(3));
				emp.setJob(rs.getString(4));
				emp.setDeptno(rs.getInt(5));
				emp.setJoindate(rs.getDate(6));
				return emp;
			}}, deptno);
		
		return empList;
	}

	public List<Employee> getEmployees(String job) {
		List<Employee> empList = jdbcTemplate.query("SELECT EMPNO, EMPNAME, SALARY, JOB, DEPTNO, JOINDATE FROM EMPLOYEE where job=?" , new RowMapper<Employee>(){

			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
				Employee emp = new Employee();
				emp.setEmpno(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setSalary(rs.getDouble(3));
				emp.setJob(rs.getString(4));
				emp.setDeptno(rs.getInt(5));
				emp.setJoindate(rs.getDate(6));
				return emp;
			}}, job);
		
		return empList;
	}

	public String getEmployeeName(int empno) {
		//String empName = jdbcTemplate.queryForObject("SELECT EMPNAME FROM EMPLOYEE WHERE EMPNO=?",java.lang.String.class, empno);
		
		NamedParameterJdbcTemplate namedTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
		Map<String, Integer> parameters = new HashMap<String, Integer>();
		parameters.put("ENO", empno);
		String empName = namedTemplate.queryForObject("SELECT EMPNAME FROM EMPLOYEE WHERE EMPNO=:ENO", parameters,java.lang.String.class);
		return empName;
	}

	public boolean updateSalary(int empno, double newsalary) {

		int result = jdbcTemplate.update("UPDATE EMPLOYEE SET SALARY=? WHERE EMPNO=?",newsalary, empno);
		if(result==1)
		return true;
		else return false;
	}

	public boolean deleteEmployee(int empno) {
		int result = jdbcTemplate.update("DELETE FROM EMPLOYEE WHERE EMPNO=?", empno);
		if(result==1)
		return true;
		else return false;
	}

}



