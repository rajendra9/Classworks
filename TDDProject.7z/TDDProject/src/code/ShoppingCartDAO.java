package code;

public interface ShoppingCartDAO {

	public boolean save(ShoppingCart cart);

}
