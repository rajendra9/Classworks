package code;

public class Book extends Product {
	
	public Book(String title, double price, int qty){
		super(title, price, qty);
	}
}
