/**
 * 
 */

var routeApp = angular.module("routeApp",['ngRoute']);
routeApp.config(function($locationProvider, $routeProvider){
	$locationProvider.hashPrefix('');
	$routeProvider
		.when("/", {
			templateUrl:'home.html',
		})
		.when("/home", {
			templateUrl:'home.html'
		})
		.when("/catalog", {
			templateUrl:'catalog.html',
			controller:'CatalogController'
		})
		.when("/search", {
			templateUrl:'search.html',
			controller:'SearchController'
				
		})
		.when("/filter", {
			templateUrl:'filter.html'
		})
		.when("/sorted", {
			templateUrl:'sorted.html',
			controller:'SortedController'
		})
		.otherwise({
			redirectTo :'/home'
		})
		
});

routeApp.controller("SearchController", function($scope){
	$scope.category='Stationary';
	$scope.productCatalog = [
	                	     {productId:"P01",productName:"Pen",description:"Reynold Blue Pen",unitPrice:20.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pen.png",category:"Stationary"},
	                	     {productId:"P02",productName:"Pencil",description:"Nataraj Black HBB Pencil",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	                	     {productId:"P02",productName:"Pencil",description:"Apsara Black HBB Pencil",unitPrice:10.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	                	     {productId:"P02",productName:"Eraser",description:"Nataraj Eraser",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	                	     {productId:"P03",productName:"Eraser",description:"Apsara Eraser",unitPrice:5.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/eraser.png",category:"Stationary"},
	                	     {productId:"P04",productName:"Books",description:"Classmate Notebook",unitPrice:50.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/book.png",category:"Stationary"},
	                	     {productId:"P05",productName:"Box",description:"Instrument Box",unitPrice:30.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/box.png",category:"Stationary"},
	                	     {productId:"P06",productName:"Scale",description:"Nataraj Scale",unitPrice:8.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/scale.png",category:"Stationary"},
	                	     {productId:"P07",productName:"Sharpner",description:"Apsara Sharpner",unitPrice:6.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/sharpner.png",category:"Stationary"},
	                	     {productId:"P08",productName:"Bag",description:"School Bag",unitPrice:350.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/bag.png",category:"Stationary"},
	                	     {productId:"P09",productName:"Mobile Charger",description:"Mobile Charger",unitPrice:250.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/charger.png",category:"Electronics"},
	                	     {productId:"P10",productName:"Travel Adapter",description:"Travel Adapter",unitPrice:299.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/adapter.png",category:"Electronics"},
	                	     {productId:"P11",productName:"Power bank",description:"Intex Power Bank",unitPrice:1200.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	                	     {productId:"P12",productName:"Power bank",description:"Kingston Power Bank",unitPrice:900.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	                	     {productId:"P12",productName:"Power bank",description:"IBall Power Bank",unitPrice:999.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	                	     {productId:"P13",productName:"Power bank",description:"Syska Power Bank",unitPrice:1100.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	                	     {productId:"P14",productName:"Pepsi Can",description:"Pepsi 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pepsi.png",category:"Beverages"},
	                	     {productId:"P15",productName:"Coke Can",description:"Coke 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/coke.png",category:"Beverages"}
	                	   ];
	
	
	
})

routeApp.controller("CatalogController", function($scope){
	$scope.productCatalog = [
	     {productId:"P01",productName:"Pen",description:"Reynold Blue Pen",unitPrice:20.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pen.png",category:"Stationary"},
	     {productId:"P02",productName:"Pencil",description:"Nataraj Black HBB Pencil",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P02",productName:"Pencil",description:"Apsara Black HBB Pencil",unitPrice:10.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P02",productName:"Eraser",description:"Nataraj Eraser",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P03",productName:"Eraser",description:"Apsara Eraser",unitPrice:5.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/eraser.png",category:"Stationary"},
	     {productId:"P04",productName:"Books",description:"Classmate Notebook",unitPrice:50.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/book.png",category:"Stationary"},
	     {productId:"P05",productName:"Box",description:"Instrument Box",unitPrice:30.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/box.png",category:"Stationary"},
	     {productId:"P06",productName:"Scale",description:"Nataraj Scale",unitPrice:8.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/scale.png",category:"Stationary"},
	     {productId:"P07",productName:"Sharpner",description:"Apsara Sharpner",unitPrice:6.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/sharpner.png",category:"Stationary"},
	     {productId:"P08",productName:"Bag",description:"School Bag",unitPrice:350.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/bag.png",category:"Stationary"},
	     {productId:"P09",productName:"Mobile Charger",description:"Mobile Charger",unitPrice:250.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/charger.png",category:"Electronics"},
	     {productId:"P10",productName:"Travel Adapter",description:"Travel Adapter",unitPrice:299.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/adapter.png",category:"Electronics"},
	     {productId:"P11",productName:"Power bank",description:"Intex Power Bank",unitPrice:1200.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P12",productName:"Power bank",description:"Kingston Power Bank",unitPrice:900.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P12",productName:"Power bank",description:"IBall Power Bank",unitPrice:999.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P13",productName:"Power bank",description:"Syska Power Bank",unitPrice:1100.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P14",productName:"Pepsi Can",description:"Pepsi 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pepsi.png",category:"Beverages"},
	     {productId:"P15",productName:"Coke Can",description:"Coke 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/coke.png",category:"Beverages"}
	   ];
})

routeApp.controller("SortedController", function($scope){
	
	$scope.employees=[
	                  {id:324, name:'Suguna Rao', job:'Developer',salary:26500.0, dept:'projects', dob: new Date("November 23,1980"), location: 'CHENNAI'},
	                  {id:354, name:'Madhavan',job:'Analyst',salary:25500.0, dept:'Quality Control', dob: new Date("January 23,1989"),  location: 'HYDERABAD'},
	                  {id:423, name:'Kadirvan',job:'Developer',salary:26500.0, dept:'projects', dob: new Date("June 23,1985"), location: 'BANGALORE'},
	                  {id:445, name:'Karthick',job:'Asst Manager',salary:27500.0, dept:'administration', dob: new Date("November 23,1980"),  location: 'MUMBAI'},
	                  {id:465, name:'Satya',job:'Project Manager',salary:47005.5, dept:'projects', dob: new Date("May 05,1982"),  location: 'CHENNAI'},
	                  {id:476, name:'Sumana',job:'Project Lead',salary:33005.5, dept:'projects', dob: new Date("November 23,1980"),  location: 'HYDERABAD'}     
	               ];
	           
	            
	            $scope.sortColumn= "name";
	            $scope.reverseSort=false;
	            
	            $scope.sortTableData = function(column) {
	            	$scope.reverseSort = ($scope.sortColumn == column) ? !$scope.reverseSort : false;
	            	$scope.sortColumn = column;
	            }
	            
	            $scope.showArrow = function(column) {
	            	if($scope.sortColumn == column) {
	            		return $scope.reverseSort ? 'arrow-down' : 'arrow-up';
	            	}
	            	return '';
	            }
	             
	
})