/**
 * 
 */

var myApp = angular.module("myModule", []);

var myController = function($scope) {
	$scope.yourName="Rahul Varma";
}
myApp.controller("myController", myController);


var empController = myApp.controller("empController", function($scope) {
	var employee = {empno:1020,
					empName:"Ramesh Kumar",
					salary:50000.0,
					dept:"Quality",
					designation:"Analyst"};
	$scope.employee = employee;
})