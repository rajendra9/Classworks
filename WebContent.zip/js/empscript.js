/**
 * 
 */

var myApp = angular.module("myModule", []);

var empController = myApp.controller("empCtrl", function($scope) {
	var employees = [
	                {empno:1020,	empName:"Ramesh Kumar",	salary:50000.0,	dept:"Quality",	designation:"Analyst"},
	                {empno:1021,	empName:"Ravi Kumar",	salary:45000.0,	dept:"HR",	designation:"Manager"},
	                {empno:1022,	empName:"Suresh Balaji",	salary:25000.0,	dept:"Quality",	designation:"Tester"},
	                {empno:1023,	empName:"Gopi M",	salary:53000.0,	dept:"HR",	designation:"Manager"},
	                {empno:1024,	empName:"Rani ",	salary:45000.0,	dept:"Projects",	designation:"Developer"},
	                {empno:1025,	empName:"Rani ",	salary:45000.0,	dept:"Projects",	designation:"Project Manager"},
	                {empno:1026,	empName:"Rani ",	salary:45000.0,	dept:"Projects",	designation:"Developer"},
	                {empno:1027,	empName:"Rani ",	salary:25000.0,	dept:"HR",	designation:"Executive"},
	                {empno:1028,	empName:"Rani ",	salary:45000.0,	dept:"Quality",	designation:"Tester"}
	                ];
	$scope.employees = employees;
})