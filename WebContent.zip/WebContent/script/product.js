/**
 * 
 */
var myApp = angular.module("myApp", []);
var productController = myApp.controller("productController", function($scope){
	$scope.categoryInput = "Stationary";
	$scope.productCatalog = [
	     {productId:"P01",productName:"Pen",description:"Reynold Blue Pen",unitPrice:20.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pen.png",category:"Stationary"},
	     {productId:"P02",productName:"Pencil",description:"Nataraj Black HBB Pencil",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P02",productName:"Pencil",description:"Apsara Black HBB Pencil",unitPrice:10.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P02",productName:"Eraser",description:"Nataraj Eraser",unitPrice:10.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pencil.png",category:"Stationary"},
	     {productId:"P03",productName:"Eraser",description:"Apsara Eraser",unitPrice:5.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/eraser.png",category:"Stationary"},
	     {productId:"P04",productName:"Books",description:"Classmate Notebook",unitPrice:50.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/book.png",category:"Stationary"},
	     {productId:"P05",productName:"Box",description:"Instrument Box",unitPrice:30.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/box.png",category:"Stationary"},
	     {productId:"P06",productName:"Scale",description:"Nataraj Scale",unitPrice:8.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/scale.png",category:"Stationary"},
	     {productId:"P07",productName:"Sharpner",description:"Apsara Sharpner",unitPrice:6.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/sharpner.png",category:"Stationary"},
	     {productId:"P08",productName:"Bag",description:"School Bag",unitPrice:350.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/bag.png",category:"Stationary"},
	     {productId:"P09",productName:"Mobile Charger",description:"Mobile Charger",unitPrice:250.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/charger.png",category:"Electronics"},
	     {productId:"P10",productName:"Travel Adapter",description:"Travel Adapter",unitPrice:299.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/adapter.png",category:"Electronics"},
	     {productId:"P11",productName:"Power bank",description:"Intex Power Bank",unitPrice:1200.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P12",productName:"Power bank",description:"Kingston Power Bank",unitPrice:900.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P12",productName:"Power bank",description:"IBall Power Bank",unitPrice:999.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P13",productName:"Power bank",description:"Syska Power Bank",unitPrice:1100.00,quantity:0,reorderLevel:10,reorderQty:20, imageUrl:"images/powerbank.png",category:"Electronics"},
	     {productId:"P14",productName:"Pepsi Can",description:"Pepsi 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/pepsi.png",category:"Beverages"},
	     {productId:"P15",productName:"Coke Can",description:"Coke 300ml can",unitPrice:35.00,quantity:50,reorderLevel:10,reorderQty:20, imageUrl:"images/coke.png",category:"Beverages"}
	   ];
	
})	
