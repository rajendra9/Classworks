/**
 * 
 */
  var myApp = angular.module("myApp", []);
  
  var titleFilter = myApp.filter("titleCase", function(){
	  return function(input){
		  return input.charAt(0).toUpperCase() + input.substr(1).toLowerCase();
	  }
  });
  
  var employeeController = myApp.controller("employeeController", function($scope){
    
	$scope.employees=[
          {id:324, name:'Suguna Rao', job:'Developer',salary:26500.0, dept:'projects', dob: new Date("November 23,1980"), location: 'CHENNAI'},
          {id:354, name:'Madhavan',job:'Analyst',salary:25500.0, dept:'Quality Control', dob: new Date("January 23,1989"),  location: 'HYDERABAD'},
          {id:423, name:'Kadirvan',job:'Developer',salary:26500.0, dept:'projects', dob: new Date("June 23,1985"), location: 'BANGALORE'},
          {id:445, name:'Karthick',job:'Asst Manager',salary:27500.0, dept:'administration', dob: new Date("November 23,1980"),  location: 'MUMBAI'},
          {id:465, name:'Satya',job:'Project Manager',salary:47005.5, dept:'projects', dob: new Date("May 05,1982"),  location: 'CHENNAI'},
          {id:476, name:'Sumana',job:'Project Lead',salary:33005.5, dept:'projects', dob: new Date("November 23,1980"),  location: 'HYDERABAD'}     
       ];
   
    $scope.rowLimit = 3;
    $scope.sortColumn= "name";
    $scope.reverseSort=false;
    
    $scope.sortTableData = function(column) {
    	$scope.reverseSort = ($scope.sortColumn == column) ? !$scope.reverseSort : false;
    	$scope.sortColumn = column;
    }
    
    $scope.showArrow = function(column) {
    	if($scope.sortColumn == column) {
    		return $scope.reverseSort ? 'arrow-down' : 'arrow-up';
    	}
    	return '';
    }
    
    $scope.searchInMultipleFields = function(item) {
    	
    	if($scope.searchText == undefined) {
    		return true;
    	}
    	else{
    		if(item.name.toLowerCase().indexOf($scope.searchText.toLowerCase()) != -1 ||
    				item.location.toLowerCase().indexOf($scope.searchText.toLowerCase()) != -1) {
    			return true;
    		}
    	}
    	return false;
    }
    
    
});

