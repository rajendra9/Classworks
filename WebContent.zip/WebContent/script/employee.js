/**
 * 
 */
var myApp = angular.module("myApp", []);
var employeeController = myApp.controller("employeeController", function($scope){
    $scope.employees=[
          {id:324, name:'Suguna Rao', job:'Developer',salary:26500.0, dept:'projects', grading:5},
          {id:354, name:'Madhavan',job:'Analyst',salary:25500.0, dept:'Quality Control', grading:4},
          {id:423, name:'Kadirvan',job:'Developer',salary:26500.0, dept:'projects',grading:3},
          {id:445, name:'Karthick',job:'Asst Manager',salary:27500.0, dept:'Administration',grading:5},
          {id:465, name:'Satya',job:'Project Manager',salary:47005.5, dept:'projects',grading:4},
          {id:476, name:'Sumana',job:'Project Lead',salary:33005.5, dept:'projects',grading:4}     
       ];
    
    
});

