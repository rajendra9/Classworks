package com.htc.jsf.beans;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.htc.jsf.bo.Employee;
import com.htc.jsf.service.EmployeeService;

@ManagedBean(name="employeeBean")
@RequestScoped
public class EmployeeBean {

	private String employeeId;
	private String employeeName;
	private String address;
	private Date joindate;
	private double salary;
	private String designation;
	private String[] skills;
	private String gender;
	private String email;
	
	public EmployeeBean(){}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getJoindate() {
		return joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String[] getSkills() {
		return skills;
	}

	public void setSkills(String[] skills) {
		this.skills = skills;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String saveEmployee(){
		EmployeeService service = new EmployeeService();
		
		StringBuffer sb = new StringBuffer();
		for(String skill: skills){
			sb.append(skill + ",");
		}
		System.out.println(sb.toString());
		System.out.println(joindate);
		boolean result = service.saveEmployee(employeeId, employeeName, address, salary, gender, designation, sb.toString(), email, joindate);
		if(result)
			return "employeeList?faces-redirect=true";
		else
			return "emperror";
	}
	
	public ArrayList<Employee> listEmployees(){
		
		EmployeeService service = new EmployeeService();
		ArrayList<Employee> empList = service.listEmployees();
		return empList;
	}
	
	public String deleteEmployee(String employeeId){
		
		EmployeeService service = new EmployeeService();
		boolean deleteStatus = service.deleteEmployee(employeeId);
		return "employeeList?faces-redirect=true";
	}
	
	public String editEmployee(String employeeId){
		EmployeeService service = new EmployeeService();
		Employee emp = service.getEmployee(employeeId);
		
		Map<String,Object> session = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		session.put("empObj", emp);

		return "editEmployee?faces-redirect=true";
	}
	
	public String updateEmployee(Employee empObj){
		EmployeeService service = new EmployeeService();
		
		//Map<String,Object> session = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		//Employee emp = (Employee) session.get("empObj");
		
		boolean updateStatus = service.updateEmployee(empObj);
		if(updateStatus)
			return "employeeList?faces-redirect=true";
		else
			return "emperror";
	}
	
}
