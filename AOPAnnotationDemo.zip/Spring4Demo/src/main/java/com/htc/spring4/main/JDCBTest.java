package com.htc.spring4.main;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.htc.spring4.beans.Employee;
import com.htc.spring4.config.JDBCConfig;
import com.htc.spring4.dao.EmployeeDAO;

public class JDCBTest {

	public static void main(String[] args) {
		
		ApplicationContext context=	new AnnotationConfigApplicationContext(JDBCConfig.class);
		EmployeeDAO employeeDAO = (EmployeeDAO) context.getBean("employeeDAO");
		
		//boolean result = employeeDAO.insertEmployee(new Employee(104,"Kishore",45000.0,"Developer",20,new Date()));
		//System.out.println(result);
		
		List<Employee> empList = employeeDAO.getEmployees(30);
		for(Employee emp: empList) {
			System.out.println(emp);
		}
		System.out.println("----------------------------");
		System.out.println(employeeDAO.getEmployeeName(101));
		System.out.println("----------------------------");
		employeeDAO.updateSalary(101, 56000.00);
		System.out.println("----------------------------");
		System.out.println(employeeDAO.getEmployee(101));
		System.out.println("----------------------------");
	}
}
