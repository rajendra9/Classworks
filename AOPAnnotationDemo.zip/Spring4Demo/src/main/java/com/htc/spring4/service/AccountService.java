package com.htc.spring4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.htc.spring4.dao.AccountDAO;

public class AccountService {
	
	@Autowired
	AccountDAO accountDAO;
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean transferMoney(int fromAccount, int toAccount, double amount){
		//
		return accountDAO.transferAmount(fromAccount, toAccount, amount);
		//
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean deposit(int accno, double amount){
		return accountDAO.deposit(accno, amount);
	}
	

	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean withdraw(int accno, double amount){
		return accountDAO.withdraw(accno, amount);
	}

}
