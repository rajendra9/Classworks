package com.htc.spring4.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.htc.spring4.beans.Address;
import com.htc.spring4.beans.Student;

@Configuration
public class StudentConfig {

	@Bean(name="address")
	public Address getAddress(){
		Address address = new Address();
		address.setDoorno("DN10");
		address.setStreet("XYZ STREET");
		address.setCity("chennai");
		address.setPincode("95495959");
		return address;
	}
	
	@Bean(name="student",autowire=Autowire.BY_NAME)
	public Student getStudent(){
		Student student = new Student();
		student.setRollno("123445");
		student.setStudentName("Ajay");
		return student;
	}
}
