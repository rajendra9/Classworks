package com.htc.spring4.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.htc.spring4.dao.AccountDAO;
import com.htc.spring4.dao.AccountDAOImpl;
import com.htc.spring4.dao.EmployeeDAO;
import com.htc.spring4.dao.EmployeeDAOImpl;
import com.htc.spring4.service.AccountService;

@Configuration
@PropertySource(value={"classpath:db.properties"})
@EnableTransactionManagement
public class AOPConfig {

	@Autowired
	Environment env;
	
	@Bean(name="dataSource")
	public DataSource getDataSource(){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
		dataSource.setUrl(env.getProperty("jdbc.url"));
		dataSource.setUsername(env.getProperty("jdbc.username"));
		dataSource.setPassword(env.getProperty("jdbc.password"));
		return dataSource;
	}
	
	@Bean(name="jdbcTemplate")
	public JdbcTemplate getJdbcTemplate(){
		JdbcTemplate jdbcTemplate = new JdbcTemplate(getDataSource());
		return jdbcTemplate;
	}
	
	@Bean(name="transactionManager")
	public DataSourceTransactionManager getTransactionManager(){
		DataSourceTransactionManager txManager = new DataSourceTransactionManager();
		txManager.setDataSource(getDataSource());
		return txManager;
	}
	
	@Bean(name="employeeDAO")
	public EmployeeDAO getEmployeeDAO(){
		EmployeeDAO employeeDAO = new EmployeeDAOImpl(getJdbcTemplate());
		return employeeDAO;
	}
	
	@Bean(name="accountDAO")
	public AccountDAO getAccountDAO(){
		AccountDAO accountDAO = new AccountDAOImpl(getJdbcTemplate());
		return accountDAO;
	}
	
	@Bean(name="AccountService")
	public AccountService getAccountService(){
		AccountService service = new AccountService();
		
		return service;
	}
}

