package com.htc.spring4.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.htc.spring4.config.AOPConfig;
import com.htc.spring4.service.AccountService;

public class AOPTest {

	public static void main(String[] args) {
		
		ApplicationContext context=	new AnnotationConfigApplicationContext(AOPConfig.class);
		AccountService accountService= (AccountService) context.getBean("AccountService");
		
		System.out.println(accountService.transferMoney(1011 ,1012 , 2000));
	}
}
