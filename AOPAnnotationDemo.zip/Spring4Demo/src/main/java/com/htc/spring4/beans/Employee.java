package com.htc.spring4.beans;

import java.util.Date;

public class Employee {

	private int empno;
	private String empname;
	private double salary;
	private String job;
	private int deptno;
	private Date joindate;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empno, String empname, double salary, String job, int deptno, Date joindate) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.salary = salary;
		this.job = job;
		this.deptno = deptno;
		this.joindate = joindate;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public Date getJoindate() {
		return joindate;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empname=" + empname + ", salary=" + salary + ", job=" + job + ", deptno="
				+ deptno + ", joindate=" + joindate + "]";
	}
	
	
}
