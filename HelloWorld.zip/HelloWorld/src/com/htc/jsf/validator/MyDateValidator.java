package com.htc.jsf.validator;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("com.htc.jsf.validator.MyDateValidator")
public class MyDateValidator implements Validator {

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		
		//String date = value.toString();
		
		Date inputDate =(Date) value;
		if(inputDate.after(new Date())){
			FacesMessage message = new FacesMessage("Joindate cannot be future date");
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(message);
		}		
	}

}
