package com.htc.jsf.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.htc.jsf.bo.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{

	public static Connection getConnection(){
		
		Connection con =null;
		try {
			DriverManager.registerDriver(new org.postgresql.Driver());
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "123Welcome");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	@Override
	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender,
			String desgination, String skills, String email, java.util.Date joindate) {
		
		boolean insertStatus = false;
		Connection con = null;
		try{
			 con = getConnection();
			PreparedStatement pst = con.prepareStatement("insert into emp values(?,?,?,?,?,?,?,?,?)");
			pst.setString(1, employeeId);
			pst.setString(2, employeeName);
			pst.setString(3, address);
			pst.setDouble(4, salary);
			pst.setDate(5, new java.sql.Date(joindate.getTime()));
			pst.setString(6, desgination);
			pst.setString(7, email);
			pst.setString(8, gender);
			pst.setString(9,skills);
			int result = pst.executeUpdate();
			if(result >0)
				insertStatus = true;
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return insertStatus;
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		Connection con = null;
		
		try {
			con = getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT EMPLOYEEID, EMPLOYEENAME, ADDRESS, SALARY, JOINDATE, DESIGNATION, EMAIL, GENDER, SKILLS FROM EMP");
			while(rs.next()){
				empList.add(new Employee(rs.getString(1),rs.getString(2),rs.getString(3), rs.getDouble(4), new java.util.Date(rs.getDate(5).getTime()), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9).split(",")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return empList;
	}

	@Override
	public Employee getEmployeeById(String employeeId) {
		Employee emp = null;
		Connection con = null;
		try {
			con = getConnection();
			PreparedStatement pst = con.prepareStatement("SELECT EMPLOYEEID, EMPLOYEENAME, ADDRESS, SALARY, JOINDATE, DESIGNATION, EMAIL, GENDER, SKILLS FROM EMP WHERE EMPLOYEEID=?");
			pst.setString(1, employeeId);
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				emp = new Employee(rs.getString(1),rs.getString(2),rs.getString(3), rs.getDouble(4), new java.util.Date(rs.getDate(5).getTime()), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9).split(","));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return emp;
	}

	@Override
	public boolean deleteEmployee(String employeeId) {
		boolean deleteStatus = false;
		Connection con = null;
		try{
			con = getConnection();
			PreparedStatement pst = con.prepareStatement("delete from emp where employeeId=?");
			pst.setString(1, employeeId);
			int result = pst.executeUpdate();
			if(result >0)
				deleteStatus = true;
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteStatus;
	}

	@Override
	public boolean updateEmployee(Employee emp) {

		boolean updateStatus = false;
		Connection con = null;
		try{
			con = getConnection();
			PreparedStatement pst = con.prepareStatement("update emp set address=?, designation=?, email=?, skills=? where employeeId=?");
			
			pst.setString(1, emp.getAddress());
			pst.setString(2, emp.getDesignation());
			pst.setString(3, emp.getEmail());
			StringBuffer sb = new StringBuffer();
			for(String skill: emp.getSkills()){
				sb.append(skill + ",");
			}
			pst.setString(4, sb.toString());
			pst.setString(5, emp.getEmployeeId());
			
			int result = pst.executeUpdate();
			if(result >0)
				updateStatus = true;
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return updateStatus;
	}

	
}
