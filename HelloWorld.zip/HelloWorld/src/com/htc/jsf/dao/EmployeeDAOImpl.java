package com.htc.jsf.dao;

import java.util.Date;

public class EmployeeDAOImpl implements EmployeeDAO{

	
	@Override
	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender,
			String desgination, String skills, String email, Date joindate) {
		System.out.println("dao method....");
		//---.............
		return true;
	}

	
}
