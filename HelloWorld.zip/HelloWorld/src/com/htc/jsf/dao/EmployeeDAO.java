package com.htc.jsf.dao;

import java.util.ArrayList;
import java.util.Date;

import com.htc.jsf.bo.Employee;

public interface EmployeeDAO {

	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender, String desgination, String skills, String email, Date joindate);
	public ArrayList<Employee>  getEmployees();
	public Employee getEmployeeById(String employeeId);
	public boolean deleteEmployee(String employeeId);
	public boolean updateEmployee(Employee  emp);
}
