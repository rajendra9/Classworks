package com.htc.jsf.dao;

import java.util.Date;

public interface EmployeeDAO {

	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender, String desgination, String skills, String email, Date joindate);
	
}
