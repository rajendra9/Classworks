package com.htc.jsf.service;

import java.util.ArrayList;
import java.util.Date;

import com.htc.jsf.bo.Employee;
import com.htc.jsf.dao.EmployeeDAO;
import com.htc.jsf.dao.EmployeeDAOImpl;

public class EmployeeService {

	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender, String desgination, String skills, String email, Date joindate) {
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		return employeeDAO.saveEmployee(employeeId, employeeName, address, salary, gender, desgination, skills, email, joindate);
	}
	
	public ArrayList<Employee> listEmployees(){
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		return employeeDAO.getEmployees();
	}
	
	public boolean deleteEmployee(String employeeId){	
		EmployeeDAO employeeDAO =new EmployeeDAOImpl();
		return employeeDAO.deleteEmployee(employeeId);
	}
	
	public Employee getEmployee(String employeeId){
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		return employeeDAO.getEmployeeById(employeeId);
	}
	
	public boolean updateEmployee(Employee emp){
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		return employeeDAO.updateEmployee(emp);
	}
	
}
