package com.htc.jsf.service;

import java.util.Date;

import com.htc.jsf.dao.EmployeeDAO;
import com.htc.jsf.dao.EmployeeDAOImpl;

public class EmployeeService {

	
	public boolean saveEmployee(String employeeId, String employeeName, String address, double salary, String gender, String desgination, String skills, String email, Date joindate) {
		System.out.println("service method...");
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		return employeeDAO.saveEmployee(employeeId, employeeName, address, salary, gender, desgination, skills, email, joindate);

	}
}
