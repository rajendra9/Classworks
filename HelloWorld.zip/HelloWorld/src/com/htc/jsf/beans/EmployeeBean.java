package com.htc.jsf.beans;

import java.util.Arrays;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;

import com.htc.jsf.service.EmployeeService;

@ManagedBean(name="employeeBean")
@SessionScoped
public class EmployeeBean {

	private String employeeId;
	private String employeeName;
	private String address;
	private Date joindate;
	private double salary;
	private String designation;
	private String[] skills;
	private String gender;
	private String email;
	
	
	public EmployeeBean(){}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getJoindate() {
		return joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String[] getSkills() {
		return skills;
	}

	public void setSkills(String[] skills) {
		this.skills = skills;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String save(){
		EmployeeService service = new EmployeeService();
		
		String commaSeperatedSkills = Arrays.toString(skills);
		
		boolean result = service.saveEmployee(employeeId, employeeName, address, salary, gender, designation, commaSeperatedSkills, email, joindate);
		if(result)
			return "empsuccess?faces-redirect=true";
		else
			return "emperror";
	}
	
	
}
