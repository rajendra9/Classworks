package com.htc.jsf.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="helloWorldBean", eager=true)
@RequestScoped
public class HelloWorldBean {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String sayHello(){
		//contact model layer....
		
		return "result";
	}
}
