package com.htc.jsf.bo;

import java.util.Arrays;
import java.util.Date;

public class Employee {

	private String employeeId;
	private String employeeName;
	private String address;
	private double salary;
	private Date joindate;
	private String designation;
	private String email;
	private String gender;
	private String[] skills;
	
	public Employee(){
		
	}

	public Employee(String employeeId, String employeeName, String address, double salary, Date joindate,
			String designation, String email, String gender, String[] skills) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.address = address;
		this.salary = salary;
		this.joindate = joindate;
		this.designation = designation;
		this.email = email;
		this.gender = gender;
		this.skills = skills;
	}


	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getJoindate() {
		return joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String[] getSkills() {
		return skills;
	}

	public void setSkills(String[] skills) {
		this.skills = skills;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", address=" + address
				+ ", salary=" + salary + ", joindate=" + joindate + ", designation=" + designation + ", email=" + email
				+ ", gender=" + gender + ", skills=" + Arrays.toString(skills) + "]";
	}
	
}
