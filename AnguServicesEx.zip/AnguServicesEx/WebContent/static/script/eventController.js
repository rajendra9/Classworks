/**
 * 
 */
var eventApp = angular.module("eventApp",['ngMessages']);
var eventController = eventApp.controller("eventController", function($scope, $log, eventService){
	
     $scope.participants = [];
	  
	  // Registering a new pariticipant.
	  $scope.submitEventForm = function(){
		  eventService.registerParticipant("/HttpServiceUsage/Participant/",
				  				            $scope.participant)
				  	  .then(function successCallback(response){
				  		  	$scope.showAllParticipants();
				  	   },function errorCallback(response){
				  			$log.error('Error while registering participants');		
				  	   });
	  }

	  // Listing all participants.
	  $scope.showAllParticipants = function(){
		  	eventService.listAllParticipant("/HttpServiceUsage/Participant/")
		  				.then(function successCallback(response){
		  					$scope.participants = response.data;
		  				},
		  				function errorCallbacl(response){
		  					$log.error('Error showing participant list');
		  				});
	  }

	  // Listing all participants.
	  $scope.removeParticipant = function(participantId){
		  	eventService.removeParticipant("/HttpServiceUsage/Participant/",
		  									participantId)
				.then(function successCallback(response){
					$scope.showAllParticipants();
				},
				function errorCallbacl(response){
					$log.error('Error during deletion');
				});  
	  }
	  $scope.showAllParticipants();
  });
  
  