/**
 * 
 */
var myApp = angular.module("eventApp", ['ngMessages','ngResource']);
myApp.factory('EventResource', ['$resource',function($resource){
	return $resource("/HttpServiceUsage/Participant/:participantId",
					 {participantId:'@participantId'}, //defaultParams
					 {}, //Actions 
					 {stripTrailingSlashes : false}); //options
}]);
var eventController = myApp.controller("eventController",function($scope, $log, EventResource){
	
	$scope.participantList = [];
		
	$scope.showAllParticipants = function(){
		$scope.participantList = EventResource.query();
	}
	
	$scope.registerParticipant = function(){
			$log.info($scope.participant);
			EventResource.save($scope.participant, function(){
				$scope.showAllParticipants();
			},function(){
				$log.error('Error');
			})
	 }

	$scope.removeParticipant = function(participantId){
		$log.info(participantId);
		    var participant = EventResource.get({participantId:participantId}, function(){
			participant.$delete(function(){
				$scope.showAllParticipants();
				$log.info("deleted");
			});
		});
	}

	$scope.showAllParticipants();

});