/**
 * 
 */
  var eventApp = angular.module("eventApp");  // get a reference to the module.
  eventApp.factory("eventServiceFactory",['$http','$log', function($http, $log){
	    
	    var eventFService = {};
	    //CODE HERE....
	    
		eventFService.registerParticipant = function(URL, participant){	
				  $log.info(participant);				  
				  var request = $http({
					  				method: 'POST',
					  				url : URL,
					  				data: participant
				  				});
				  return request;
		};
		
		eventFService.removeParticipant = function(URL, participantId){	
				  $log.info(participantId);				  
				  var request = $http({
					  				method: 'DELETE',
					  				url : URL + participantId,
				  				});
				  return request;
		};
		eventFService.searchParticipant = function(URL, participantId){	
				  $log.info(participant);				  
				  var request = $http({
					  				method: 'GET',
					  				url : URL + participantId,
				  				});
				  return request;
		};
		eventFService.listAllParticipant = function(URL){	  
				  var request = $http({
					  				method: 'GET',
					  				url : URL,
				  				});
				  return request;
		}
		
		
	    return eventFService;
  }]);
