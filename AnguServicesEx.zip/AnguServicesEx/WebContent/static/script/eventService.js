/**
 * 
 */
  var eventApp = angular.module("eventApp");  // Get a reference to the module.
  eventApp.service("eventService",['$http','$log', function($http, $log){
	  
		return {
			//register participant service.
			registerParticipant : function(URL, participant){	
				  $log.info(participant);				  
				  var request = $http({
					  				method: 'POST',
					  				url : URL,
					  				data: participant
				  				});
				  return request;
			},
			removeParticipant : function(URL, participantId){	
				  $log.info(participantId);				  
				  var request = $http({
					  				method: 'DELETE',
					  				url : URL + participantId,
				  				});
				  return request;
			},
			searchParticipant : function(URL, participantId){	
				  $log.info(participant);				  
				  var request = $http({
					  				method: 'GET',
					  				url : URL + participantId,
				  				});
				  return request;
			},
			listAllParticipant : function(URL){	  
				  var request = $http({
					  				method: 'GET',
					  				url : URL,
				  				});
				  return request;
			}
	    }
  }]);
