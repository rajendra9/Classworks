package com.htc.events.model;

public class Participant {

	private Long participantId;
	private String participantName;
	private String address;
	private String email;
	private String contactno;
	private String gender;
	private String newsletter;
	
	public Participant(){
		participantId = 0L;
	}

	public Participant(Long participantId, String participantName, String address, String email, String contactNo,
			String gender, String newsletter) {
		super();
		this.participantId = participantId;
		this.participantName = participantName;
		this.address = address;
		this.email = email;
		this.contactno = contactNo;
		this.gender = gender;
		this.newsletter = newsletter;
	}

	public Long getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Long participantId) {
		this.participantId = participantId;
	}

	public String getParticipantName() {
		return participantName;
	}

	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactNo) {
		this.contactno = contactNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNewsletter() {
		return newsletter;
	}

	public void setNewsletter(String newsletter) {
		this.newsletter = newsletter;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((contactno == null) ? 0 : contactno.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((newsletter == null) ? 0 : newsletter.hashCode());
		result = prime * result + ((participantId == null) ? 0 : participantId.hashCode());
		result = prime * result + ((participantName == null) ? 0 : participantName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Participant other = (Participant) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (contactno == null) {
			if (other.contactno != null)
				return false;
		} else if (!contactno.equals(other.contactno))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (newsletter == null) {
			if (other.newsletter != null)
				return false;
		} else if (!newsletter.equals(other.newsletter))
			return false;
		if (participantId == null) {
			if (other.participantId != null)
				return false;
		} else if (!participantId.equals(other.participantId))
			return false;
		if (participantName == null) {
			if (other.participantName != null)
				return false;
		} else if (!participantName.equals(other.participantName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Participant [participantId=" + participantId + ", participantName=" + participantName + ", address="
				+ address + ", email=" + email + ", contactNo=" + contactno + ", gender=" + gender + ", newsletter="
				+ newsletter + "]";
	}
	
}
